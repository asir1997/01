__version__ = "8.2.5"
__release__ = True
